var __config = {
    "Name": "x1", "Url": "http://localhost:9894/custompicklist/Grid/SimpleGrid.asmx",
    "Detail": { "Method": "MockData", "SettingGrid": { "SortName": "ListName", "SortOrder": true, "CurrentPage": 1, "MaxPerPage": 50, "MaxRows": 0, "IsToggle": false },
        "Schema": [{ "Name": "ListName", "Desc": "שם פרטי", "Width": 145, "CanSort": true }, { "Name": "MemberCount", "Desc": "שם משפחה", "Width": 222, "CanSort": false }, 
    { "Name": "CampaignName", "Desc": "dd f", "Width": 100, "CanSort": true}], "FilterFields": []} };