﻿function new_clientCaller(id, method) {
    this.CallerMethod = method;
    this.Send = function (gridProp, callback, err) {
        var payload = { "request": { Id: id, SettingGrid: gridProp} };
        try {
            var data = CallerMethod(payload);
            callback(data.d);

        } catch (e) {
            err(e.Description);

        }
    };
}