﻿var isCrm = false;//true
var configUri = "new_configlumock"; //new_configlu
